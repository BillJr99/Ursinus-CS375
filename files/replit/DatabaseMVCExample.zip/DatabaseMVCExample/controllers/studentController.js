const Student = require('../models/studentModel');

exports.create = (req, res) => {
  const { name, email, password } = req.body;
  Student.createStudent(name, email, password, (err, studentId) => {
    if (req.headers.accept?.includes('application/json')) {
      // Handle API call (JSON response)
      if (err) return res.status(500).json({ error: err.message });
      return res.status(201).json({ id: studentId, name, email });
    } else {
      // Handle form submission (HTML response)
      if (err) {
        return res.render('students/add', {
          message: { type: 'error', text: 'Failed to add student: ' + err.message }
        });
      }
      return res.render('students/add', {
        message: { type: 'success', text: 'Student added successfully!' }
      });
    }
  });
};

exports.getById = (req, res) => {
  const id = req.params.id;
  Student.getStudentById(id, (err, student) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!student) return res.status(404).json({ error: "Student not found" });
    res.json(student);
  });
};

exports.list = (req, res) => {
    Student.getAllStudents((err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

exports.listCallback = (req, res, callback) => {
  Student.getAllStudents((err, rows) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, rows);
  });
};

exports.update = (req, res) => {
    const { name, email } = req.body;
    Student.updateStudent(req.params.id, name, email, (err, changes) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ updated: changes });
    });
};

exports.remove = (req, res) => {
    Student.deleteStudent(req.params.id, (err, changes) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: changes });
    });
};
