const express = require('express');
const router = express.Router();
const enrollmentController = require('../controllers/enrollmentController');
const courseController = require('../controllers/courseController');
const studentController = require('../controllers/studentController');
const { verifyAccessToken } = require('../auth/jwt');
const db = require('../db');

/**
 * @swagger
 * tags:
 *   name: Enrollments
 *   description: API endpoints for managing enrollments
 */

/**
 * @swagger
 * /enrollments:
 *   get:
 *     summary: Retrieve a list of enrollments
 *     tags: [Enrollments]
 *     responses:
 *       200:
 *         description: A list of enrollments.
 */
router.get('/', verifyAccessToken, enrollmentController.list);

/**
 * @swagger
 * /enrollments:
 *   post:
 *     summary: Enroll a student in a course
 *     tags: [Enrollments]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               student_id:
 *                 type: integer
 *               course_id:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Enrollment created successfully.
 */
router.post('/', enrollmentController.create);

/**
 * @swagger
 * /enrollments/{id}:
 *   delete:
 *     summary: Remove a student's enrollment
 *     tags: [Enrollments]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the enrollment to remove
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Enrollment removed successfully.
 */
router.delete('/:id', verifyAccessToken, enrollmentController.remove);

// Route to display the enrollment form
router.get('/add', (req, res) => {
  // Fetch students and courses concurrently
  Promise.all([
    new Promise((resolve, reject) => {
      studentController.listCallback(req, res, (err, students) => {
        if (err) reject(err);
        else resolve(students);
      });
    }),
    new Promise((resolve, reject) => {
      courseController.listCallback(req, res, (err, courses) => {
        if (err) reject(err);
        else resolve(courses);
      });
    })
  ])
  .then(([students, courses]) => {
    // Render the form with students and courses data
    res.render('enrollments/add', { students, courses, message: null });
  })
  .catch(err => {
    // Handle errors
    res.status(500).send('Database error: ' + err.message);
  });
});

// Route to handle the enrollment form submission
router.post('/add', enrollmentController.create);

module.exports = router;
