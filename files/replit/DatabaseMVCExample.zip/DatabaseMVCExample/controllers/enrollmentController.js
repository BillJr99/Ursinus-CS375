const Enrollment = require('../models/enrollmentModel');

exports.create = (req, res) => {
  const { studentId, courseId } = req.body;
  Enrollment.enrollStudent(studentId, courseId, (err, id) => {
    if (err) {
      // Handle error (e.g., duplicate entry)
      return res.render('enrollments/add', { message: { type: 'error', text: 'Failed to add enrollment: ' + err.message } });
    }
    // Success: Render the 'add' view with a success message
    const successMessage = `Enrollment added successfully with ID ${id}`;
    res.render('enrollments/add', { message: { type: 'success', text: successMessage } });
  });
};

exports.list = (_, res) => {
    Enrollment.getAllEnrollments((err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

exports.remove = (req, res) => {
    Enrollment.deleteEnrollment(req.params.id, (err, changes) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: changes });
    });
};
