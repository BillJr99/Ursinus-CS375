const Course = require('../models/courseModel');

exports.create = (req, res) => {
  const { name, code } = req.body;
  Course.createCourse(name, code, (err, id) => {
    if (err) {
      // Handle error (e.g., duplicate entry)
      return res.render('courses/add', { message: { type: 'error', text: 'Failed to add course: ' + err.message } });
    }
    // Success: Render the 'add' view with a success message
    const successMessage = `Course added successfully with ID ${id}`;
    res.render('courses/add', { message: { type: 'success', text: successMessage } });
  });
};

exports.list = (_, res) => {
    Course.getAllCourses((err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

exports.listCallback = (req, res, callback) => {
  Course.getAllCourses((err, rows) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, rows);
  });
};

exports.update = (req, res) => {
    const { name, code } = req.body;
    Course.updateCourse(req.params.id, name, code, (err, changes) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ updated: changes });
    });
};

exports.remove = (req, res) => {
    Course.deleteCourse(req.params.id, (err, changes) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: changes });
    });
};
