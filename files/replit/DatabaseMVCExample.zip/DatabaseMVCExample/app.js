require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const setupSwagger = require('./swagger');
const app = express();
const PORT = process.env.PORT || 3000;

const db = require('./db'); // Initialize DB

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());
setupSwagger(app);

app.set('view engine', 'ejs');

app.use('/students', require('./routes/studentRoutes'));
app.use('/courses', require('./routes/courseRoutes'));
app.use('/enrollments', require('./routes/enrollmentRoutes'));
app.use('/auth', require('./routes/authRoutes'));

app.get('/', (req, res) => {
  const query = `
    SELECT Student.id AS student_id, Student.name AS student_name, Student.email, 
           Course.id AS course_id, Course.name AS course_name, Course.code
    FROM Enrollment
    JOIN Student ON Enrollment.student_id = Student.id
    JOIN Course ON Enrollment.course_id = Course.id
    ORDER BY Student.id, Course.id;
  `;

  db.all(query, [], (err, rows) => {
    if (err) {
      return res.status(500).send('Database error: ' + err.message);
    }
    res.render('index', { enrollments: rows });
  });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    console.log(`Swagger docs at http://localhost:${PORT}/api-docs`);
});