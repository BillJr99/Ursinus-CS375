const db = require('../db');

exports.enrollStudent = (student_id, course_id, callback) => {
    db.run(
        'INSERT INTO Enrollment (student_id, course_id) VALUES (?, ?)',
        [student_id, course_id],
        function (err) {
            callback(err, this?.lastID);
        }
    );
};

exports.getAllEnrollments = (callback) => {
    const query = `
        SELECT Enrollment.id, Student.name AS student, Course.name AS course, Student.id AS student_id, Student.email, Course.id as course_id, Course.code
        FROM Enrollment
        JOIN Student ON Enrollment.student_id = Student.id
        JOIN Course ON Enrollment.course_id = Course.id
    `;
    db.all(query, [], callback);
};

exports.deleteEnrollment = (id, callback) => {
    db.run('DELETE FROM Enrollment WHERE id = ?', [id], function (err) {
        callback(err, this?.changes);
    });
};

exports.getEnrollmentById = (id, callback) => {
  db.get(
    'SELECT id, student_id, course_id, enrollment_date FROM Enrollment WHERE id = ?',
    [id],
    (err, row) => {
      callback(err, row);
    }
  );
};
