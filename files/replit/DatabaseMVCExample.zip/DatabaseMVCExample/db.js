require('dotenv').config();
const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database(process.env.DB_FILE || './database.db', (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to SQLite database.');
    }
});

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS Student (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS Course (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            code TEXT UNIQUE NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS Enrollment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            course_id INTEGER,
            FOREIGN KEY(student_id) REFERENCES Student(id),
            FOREIGN KEY(course_id) REFERENCES Course(id),
            UNIQUE(student_id, course_id)
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS Session (
            id TEXT PRIMARY KEY,
            student_id INTEGER,
            refresh_token TEXT NOT NULL,
            issued_at INTEGER,
            expires_at INTEGER,
            FOREIGN KEY(student_id) REFERENCES Student(id)
        )
    `);
});

module.exports = db;
