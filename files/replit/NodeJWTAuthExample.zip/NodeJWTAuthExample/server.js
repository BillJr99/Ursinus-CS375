const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const cookieParser = require('cookie-parser');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'super_secret_key';

const ACCESS_TOKEN_EXPIRES_IN = '15m';
const REFRESH_TOKEN_EXPIRES_IN_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.redirect('/login.html');
});

const db = new sqlite3.Database('./db.sqlite');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS refresh_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    token TEXT UNIQUE,
    issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME,
    user_agent TEXT,
    ip_address TEXT
  )`);
});

const fs = require('fs');

function logMessage(message) {
    const logStream = fs.createWriteStream('application.log', { flags: 'a' });
    const timestamp = new Date().toISOString();
    logStream.write(`[${timestamp}] ${message}\n`);
    logStream.end();
}

function generateAccessToken(user) {
  return jwt.sign(user, SECRET_KEY, { expiresIn: ACCESS_TOKEN_EXPIRES_IN });
}

function verifyJWT(req, res, next) {
  logMessage(`Incoming request to: ${req.originalUrl}`);

  const authHeader = req.headers['authorization'];
  if (!authHeader) {
    logMessage(`No Authorization header found.`);
    return res.redirect('/login.html');
  }

  const token = authHeader.split(' ')[1];
  if (!token) {
    logMessage(`Bearer token missing in Authorization header.`);
    return res.redirect('/login.html');
  }

  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) {
      logMessage(`Token verification failed: ${err.name} - ${err.message}`);
      return res.redirect('/login.html');
    }

    logMessage(`Token successfully verified for user: ${decoded.username}`);
    req.user = decoded;
    next();
  });
}

app.get('/dashboard.html', verifyJWT, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, row) => {
    if (row) return res.status(400).json({ error: 'User exists' });

    const hash = await bcrypt.hash(password, 10);
    db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hash], err => {
      if (err) return res.status(500).json({ error: 'Failed to register' });
      res.json({ message: 'User registered' });
    });
  });
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const accessToken = generateAccessToken({ username });
    const refreshToken = uuidv4();
    const expiresAt = new Date(Date.now() + REFRESH_TOKEN_EXPIRES_IN_MS);
    const userAgent = req.headers['user-agent'] || 'unknown';
    const ipAddress = req.ip;

    db.run(
      `INSERT INTO refresh_tokens (username, token, expires_at, user_agent, ip_address)
       VALUES (?, ?, ?, ?, ?)`,
      [username, refreshToken, expiresAt.toISOString(), userAgent, ipAddress]
    );

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: false,
      sameSite: 'Strict',
      maxAge: REFRESH_TOKEN_EXPIRES_IN_MS
    });

    res.json({ accessToken });
  });
});

app.post('/api/refresh', (req, res) => {
  const oldToken = req.cookies.refreshToken;
  if (!oldToken) return res.status(401).json({ error: 'Missing refresh token' });

  db.get('SELECT * FROM refresh_tokens WHERE token = ?', [oldToken], (err, session) => {
    if (!session) return res.status(403).json({ error: 'Invalid or expired session' });

    const now = new Date();
    if (new Date(session.expires_at) < now) {
      db.run('DELETE FROM refresh_tokens WHERE token = ?', [oldToken]);
      return res.status(403).json({ error: 'Refresh token expired' });
    }

    const newToken = uuidv4();
    const newExpiresAt = new Date(Date.now() + REFRESH_TOKEN_EXPIRES_IN_MS);
    const userAgent = req.headers['user-agent'] || 'unknown';
    const ipAddress = req.ip;

    db.serialize(() => {
      db.run('DELETE FROM refresh_tokens WHERE token = ?', [oldToken]);
      db.run(`INSERT INTO refresh_tokens (username, token, expires_at, user_agent, ip_address)
              VALUES (?, ?, ?, ?, ?)`,
        [session.username, newToken, newExpiresAt.toISOString(), userAgent, ipAddress]);
    });

    const newAccessToken = generateAccessToken({ username: session.username });

    res.cookie('refreshToken', newToken, {
      httpOnly: true,
      secure: false,
      sameSite: 'Strict',
      maxAge: REFRESH_TOKEN_EXPIRES_IN_MS
    });

    res.json({ accessToken: newAccessToken });
  });
});

app.post('/api/logout', (req, res) => {
  const token = req.cookies.refreshToken;
  if (token) {
    db.run('DELETE FROM refresh_tokens WHERE token = ?', [token]);
    res.clearCookie('refreshToken');
  }
  res.json({ message: 'Logged out' });
});

app.get('/api/sessions', verifyJWT, (req, res) => {
  db.all(
    `SELECT id, issued_at, expires_at, user_agent, ip_address
     FROM refresh_tokens WHERE username = ?`,
    [req.user.username],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Could not retrieve sessions' });
      res.json({ sessions: rows });
    }
  );
});

app.post('/api/sessions/revoke', verifyJWT, (req, res) => {
  const { sessionId } = req.body;

  db.run(
    `DELETE FROM refresh_tokens WHERE id = ? AND username = ?`,
    [sessionId, req.user.username],
    function (err) {
      if (err || this.changes === 0) {
        return res.status(400).json({ error: 'Session not found or not owned' });
      }
      res.json({ message: 'Session revoked' });
    }
  );
});

app.get('/api/dashboard', verifyJWT, (req, res) => {
  const query = `
    SELECT
      u.id AS user_id,
      u.username,
      u.password,
      rt.id AS refresh_token_id,
      rt.token,
      rt.issued_at,
      rt.expires_at,
      rt.user_agent,
      rt.ip_address
    FROM
      users u
    LEFT JOIN
      refresh_tokens rt ON u.username = rt.username
  `;

  db.all(query, [], (err, rows) => {
    if (err) {
      console.error('Error retrieving data:', err.message);
      return res.status(500).json({ message: 'Internal server error' });
    }
    res.status(200).json(rows);
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
