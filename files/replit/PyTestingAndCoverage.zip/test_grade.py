import unittest
from main import get_grade

# run with python -m unittest test_grade
# generate coverage with coverage run -m unittest test_grade
# view coverage report with coverage report or coverage html
class TestGrades(unittest.TestCase):

  def test_A(self):
    self.assertEqual(get_grade(90), "A")

  def test_C(self):
    self.assertEqual(get_grade(75), "C")

if __name__ == '__main__':
  unittest.main()
