const Student = require('../models/studentModel');

exports.create = (req, res) => {
  const { name, email, password } = req.body;
  Student.createStudent(name, email, password, (err, id) => {
    if (err) {
      // Handle error (e.g., duplicate entry)
      return res.render('students/add', { message: { type: 'error', text: 'Failed to add student: ' + err.message } });
    }
    // Success: Render the 'add' view with a success message
    const successMessage = `Student added successfully with ID ${id}`;
    res.render('students/add', { message: { type: 'success', text: successMessage } });
  });
};

exports.list = (req, res) => {
    Student.getAllStudents((err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

exports.listCallback = (req, res, callback) => {
  Student.getAllStudents((err, rows) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, rows);
  });
};

exports.update = (req, res) => {
    const { name, email } = req.body;
    Student.updateStudent(req.params.id, name, email, (err, changes) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ updated: changes });
    });
};

exports.remove = (req, res) => {
    Student.deleteStudent(req.params.id, (err, changes) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: changes });
    });
};
