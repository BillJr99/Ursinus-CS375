const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const { verifyAccessToken } = require('../auth/jwt');

/**
 * @swagger
 * tags:
 *   name: Students
 *   description: API endpoints for managing students
 */

/**
 * @swagger
 * /students:
 *   get:
 *     summary: Retrieve a list of students
 *     tags: [Students]
 *     responses:
 *       200:
 *         description: A list of students.
 */
router.get('/', verifyAccessToken, studentController.list);

/**
 * @swagger
 * /students:
 *   post:
 *     summary: Create a new student
 *     tags: [Students]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       201:
 *         description: Student created successfully.
 */
router.post('/', studentController.create);

/**
 * @swagger
 * /students/{id}:
 *   put:
 *     summary: Update an existing student
 *     tags: [Students]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the student to update
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *     responses:
 *       200:
 *         description: Student updated successfully.
 */
router.put('/:id', verifyAccessToken, studentController.update);

/**
 * @swagger
 * /students/{id}:
 *   delete:
 *     summary: Delete a student
 *     tags: [Students]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the student to delete
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Student deleted successfully.
 */
router.delete('/:id', verifyAccessToken, studentController.remove);

// Display form to add a new student
router.get('/add', (req, res) => {
  res.render('students/add');
});

// Route to handle the form submission
router.post('/add', studentController.create);

module.exports = router;
