const Student = require('../models/studentModel');
const bcrypt = require('bcrypt');
const {
    generateAccessToken,
    generateRefreshToken,
    rotateRefreshToken,
    getSessions,
    revokeSession
} = require('../auth/jwt');

exports.register = async (req, res) => {
    const { name, email, password } = req.body;
    Student.createStudent(name, email, password, (err, id) => {
        if (err) return res.status(400).json({ error: err.message });
        res.status(201).json({ id });
    });
};

exports.login = (req, res) => {
    const { email, password } = req.body;
    Student.findByEmail(email, async (err, user) => {
        if (err || !user) return res.status(401).json({ error: 'Invalid credentials' });
        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.status(401).json({ error: 'Invalid credentials' });
        const accessToken = generateAccessToken(user);
        generateRefreshToken(user.id, (err, refreshToken) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ accessToken, refreshToken });
        });
    });
};

exports.refresh = (req, res) => {
    const { refreshToken } = req.body;
    rotateRefreshToken(refreshToken, (err, newToken) => {
        if (err) return res.status(401).json({ error: 'Invalid or expired refresh token' });
        res.json({ refreshToken: newToken });
    });
};

exports.sessions = (req, res) => {
    getSessions(req.user.id, (err, sessions) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(sessions);
    });
};

exports.revoke = (req, res) => {
    revokeSession(req.params.sessionId, (err, changes) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ revoked: changes });
    });
};

exports.logout = (req, res) => {
  res.clearCookie('token'); 
  res.redirect('/');
};
