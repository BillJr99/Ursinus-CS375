const Enrollment = require('../models/enrollmentModel');

exports.create = (req, res) => {
  const { student_id, course_id } = req.body;
  Enrollment.enrollStudent(student_id, course_id, (err, enrollmentId) => {
    if (req.is('application/json')) {
      // Handle API call (JSON response)
      if (err) return res.status(500).json({ error: err.message });
      return res.status(201).json({
        message: {
          type: 'success',
          text: 'Enrollment added successfully!',
        },
        id: enrollmentId,
        student_id,
        course_id
      });
    } else {
      // Handle form submission (HTML response)
      if (err) {
        return res.render('enrollments/add', {
          message: { type: 'error', text: 'Failed to add enrollment: ' + err.message }
        });
      }
      return res.render('enrollments/add', {
        message: { type: 'success', text: 'Enrollment added successfully!' }
      });
    }
  });
};

exports.list = (_, res) => {
    Enrollment.getAllEnrollments((err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

exports.remove = (req, res) => {
    Enrollment.deleteEnrollment(req.params.id, (err, changes) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: changes });
    });
};

exports.getById = (req, res) => {
  const id = req.params.id;
  Enrollment.getEnrollmentById(id, (err, enrollment) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!enrollment) return res.status(404).json({ error: "Enrollment not found" });
    res.json(enrollment);
  });
};
