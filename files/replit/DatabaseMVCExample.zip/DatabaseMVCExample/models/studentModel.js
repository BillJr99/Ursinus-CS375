const db = require('../db');
const bcrypt = require('bcrypt');

exports.createStudent = async (name, email, password, callback) => {
    const hashed = await bcrypt.hash(password, 10);
    db.run(
        'INSERT INTO Student (name, email, password) VALUES (?, ?, ?)',
        [name, email, hashed],
        function (err) {
            callback(err, this?.lastID);
        }
    );
};

exports.getAllStudents = (callback) => {
    db.all('SELECT id, name, email FROM Student', [], callback);
};

exports.updateStudent = (id, name, email, callback) => {
    db.run(
        'UPDATE Student SET name = ?, email = ? WHERE id = ?',
        [name, email, id],
        function (err) {
            callback(err, this?.changes);
        }
    );
};

exports.deleteStudent = (id, callback) => {
    db.run('DELETE FROM Student WHERE id = ?', [id], function (err) {
        callback(err, this?.changes);
    });
};

exports.findByEmail = (email, callback) => {
    db.get('SELECT * FROM Student WHERE email = ?', [email], callback);
};
