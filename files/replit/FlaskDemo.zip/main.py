from flask import Flask, jsonify, abort, make_response, request
from random import randint

app = Flask(__name__)


@app.route('/')
def hello_world():
  return 'Hello, World!'


# curl -i -H "Content-Type: application/json" -X POST -d '{"data": {"password": "abc"}}' http://localhost:5000/api/v1/rand/5
@app.route('/api/v1/rand/<int:maxval>', methods=['POST'])
def randfunc(maxval=10):
  if maxval < 0:
    abort(400)

  if not 'data' in request.json:
    abort(400)

  if not 'password' in request.json['data']:
    abort(401)

  password = request.json['data'].get('password', "")

  if password != "abc":
    abort(401)

  result = randint(0, maxval)

  return make_response(jsonify({'data': result}), 200)


if __name__ == '__main__':
  app.run()
