const Course = require('../models/courseModel');

exports.create = (req, res) => {
  const { name, code } = req.body;
  Course.createCourse(name, code, (err, courseId) => {
    if (req.headers.accept?.includes('application/json')) {
      // Handle API call (JSON response)
      if (err) return res.status(500).json({ error: err.message });
      return res.status(201).json({ id: courseId, name, code });
    } else {
      // Handle form submission (HTML response)
      if (err) {
        return res.render('courses/add', {
          message: { type: 'error', text: 'Failed to add course: ' + err.message }
        });
      }
      return res.render('courses/add', {
        message: { type: 'success', text: 'Course added successfully!' }
      });
    }
  });
};

exports.list = (_, res) => {
    Course.getAllCourses((err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
};

exports.listCallback = (req, res, callback) => {
  Course.getAllCourses((err, rows) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, rows);
  });
};

exports.update = (req, res) => {
    const { name, code } = req.body;
    Course.updateCourse(req.params.id, name, code, (err, changes) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ updated: changes });
    });
};

exports.remove = (req, res) => {
    Course.deleteCourse(req.params.id, (err, changes) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: changes });
    });
};

exports.getById = (req, res) => {
  const id = req.params.id;
  Course.getCourseById(id, (err, course) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!course) return res.status(404).json({ error: "Course not found" });
    res.json(course);
  });
};
