const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const courseController = require('../controllers/courseController');
const db = require('../db'); 

router.get('/', (req, res) => {
  const query = `
    SELECT Student.id AS student_id, Student.name AS student_name, Student.email, 
           Course.id AS course_id, Course.name AS course_name, Course.code
    FROM Enrollment
    JOIN Student ON Enrollment.student_id = Student.id
    JOIN Course ON Enrollment.course_id = Course.id
    ORDER BY Student.id, Course.id;
  `;

  db.all(query, [], (err, rows) => {
    if (err) {
      return res.status(500).send('Database error: ' + err.message);
    }
    res.render('index', { enrollments: rows });
  });
});

router.get('/students/add', (req, res) => {
  res.render('students/add');
});

router.get('/courses/add', (req, res) => {
  res.render('courses/add');
});

router.get('/enrollments/add', (req, res) => {
  // Fetch students and courses concurrently
  Promise.all([
    new Promise((resolve, reject) => {
      studentController.listCallback(req, res, (err, students) => {
        if (err) reject(err);
        else resolve(students);
      });
    }),
    new Promise((resolve, reject) => {
      courseController.listCallback(req, res, (err, courses) => {
        if (err) reject(err);
        else resolve(courses);
      });
    })
  ])
  .then(([students, courses]) => {
    // Render the form with students and courses data
    res.render('enrollments/add', { students, courses, message: null });
  })
  .catch(err => {
    // Handle errors
    res.status(500).send('Database error: ' + err.message);
  });
});

module.exports = router;
