const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

// In-memory session store (replace with DB in production)
const sessions = {};

const JWT_SECRET = process.env.JWT_SECRET || 'secret';
const REFRESH_SECRET = process.env.REFRESH_SECRET || 'refreshsecret';

exports.generateAccessToken = function (user) {
  return jwt.sign(
    { id: user.id, email: user.email },
    JWT_SECRET,
    { expiresIn: '15m' } // short-lived access token
  );
};

exports.generateRefreshToken = function (userId, callback) {
  try {
    const sessionId = uuidv4();
    const refreshToken = jwt.sign(
      { sessionId, id: userId },
      REFRESH_SECRET,
      { expiresIn: '7d' }
    );
    sessions[sessionId] = {
      userId,
      createdAt: new Date(),
      active: true
    };
    callback(null, refreshToken);  
  } catch (err) {
    callback(err); 
  }
};

exports.rotateRefreshToken = function (oldToken) {
  try {
    const payload = jwt.verify(oldToken, REFRESH_SECRET);
    const sessionId = payload.sessionId;
    if (!sessions[sessionId] || !sessions[sessionId].active) {
      throw new Error("Invalid or revoked session");
    }

    // Rotate: deactivate old, issue new
    sessions[sessionId].active = false;
    const newSessionId = uuidv4();
    sessions[newSessionId] = {
      userId: payload.id,
      createdAt: new Date(),
      active: true
    };

    const newToken = jwt.sign(
      { sessionId: newSessionId, id: payload.id, email: payload.email },
      REFRESH_SECRET,
      { expiresIn: '7d' }
    );

    return newToken;
  } catch (err) {
    throw new Error("Invalid refresh token");
  }
};

exports.getSessions = function (userId) {
  return Object.entries(sessions)
    .filter(([_, s]) => s.userId === userId)
    .map(([id, s]) => ({ sessionId: id, createdAt: s.createdAt, active: s.active }));
};

exports.revokeSession = function (sessionId) {
  if (sessions[sessionId]) {
    sessions[sessionId].active = false;
  }
};

exports.verifyAccessToken = function (req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};
