import pathlib
# import tkinter as tk
# import tkinter.ttk as ttk
from tkinter import messagebox
import pygubu

# from https://github.com/alejandroautalan/pygubu
# helloworld.py

# design with pip install pygubu-designer; pygubu-designer
PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "dialog.ui"


class HelloworldApp:

    def __init__(self, master=None):
        # 1: Create a builder and setup resources path (if you have images)
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)

        # 2: Load an ui file
        builder.add_from_file(PROJECT_UI)

        # 3: Create the mainwindow
        self.mainwindow = builder.get_object('mainwindow', master)
        self.entry2 = builder.get_object(
            'entry2', master)  # for each ui element

        # 4: Connect callbacks
        builder.connect_callbacks(self)
        # get name from ui file for each callback
        callbacks = {"button_clicked": self.button_clicked}
        builder.connect_callbacks(callbacks)

    def run(self):
        self.mainwindow.mainloop()

    def button_clicked(self):
        color = self.entry2.get()
        messagebox.showinfo("Your favorite color", "My favorite color is {} too!".format(
            color), parent=self.mainwindow)


if __name__ == '__main__':
    app = HelloworldApp()
    app.run()
