const request = require("supertest");
const expect = require("chai").expect;
const express = require("express");
const bodyParser = require("body-parser");

const studentRoutes = require("../routes/studentRoutes");
const courseRoutes = require("../routes/courseRoutes");
const enrollmentRoutes = require("../routes/enrollmentRoutes");

const app = express();
app.use("/api/students", studentRoutes);
app.use("/api/courses", courseRoutes);
app.use("/api/enrollments", enrollmentRoutes);

describe("API Integration Tests", function () {
    let studentId, courseId, enrollmentId;

    it("should create a new student", async function () {
        const res = await request(app)
            .post("/api/students")
            .send({
                name: "Test Student",
                email: "test@student.com",
                password: "password123",
            });
        expect(res.status).to.equal(201);
        studentId = res.body.id;
    });

    it("should create a new course", async function () {
        const res = await request(app)
            .post("/api/courses")
            .send({ name: "Test Course", code: "CS101" });
        expect(res.status).to.equal(201);
        courseId = res.body.id;
    });

    it("should enroll the student in the course", async function () {
        const res = await request(app)
            .post("/api/enrollments")
            .send({ student_id: studentId, course_id: courseId });
        expect(res.status).to.equal(201);
        enrollmentId = res.body.id;
    });

    it("should retrieve all enrollments", async function () {
        const res = await request(app).get("/api/enrollments");
        expect(res.status).to.equal(200);
        expect(res.body).to.be.an("array");
    });

    it("should delete the enrollment", async function () {
        const res = await request(app).delete(
            `/api/enrollments/${enrollmentId}`,
        );
        expect(res.status).to.equal(200);
    });

    it("should delete the student", async function () {
        const res = await request(app).delete(`/api/students/${studentId}`);
        expect(res.status).to.equal(200);
    });

    it("should delete the course", async function () {
        const res = await request(app).delete(`/api/courses/${courseId}`);
        expect(res.status).to.equal(200);
    });
});
