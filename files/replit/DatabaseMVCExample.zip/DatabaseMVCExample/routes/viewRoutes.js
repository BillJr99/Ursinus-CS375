const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const courseController = require('../controllers/courseController');
const enrollmentController = require('../controllers/enrollmentController');
const db = require('../db'); 

router.get('/', (req, res) => {
  enrollmentController.listCallback(req, res, (err, rows) => {
    if (err) return res.status(500).send('Database error: ' + err.message);
    res.render('index', { enrollments: rows });
  });
});

router.get('/students/add', (req, res) => {
  res.render('students/add');
});

router.get('/courses/add', (req, res) => {
  res.render('courses/add');
});

router.get('/enrollments/add', (req, res) => {
  // Fetch students and courses concurrently
  Promise.all([
    new Promise((resolve, reject) => {
      studentController.listCallback(req, res, (err, students) => {
        if (err) reject(err);
        else resolve(students);
      });
    }),
    new Promise((resolve, reject) => {
      courseController.listCallback(req, res, (err, courses) => {
        if (err) reject(err);
        else resolve(courses);
      });
    })
  ])
  .then(([students, courses]) => {
    // Render the form with students and courses data
    res.render('enrollments/add', { students, courses, message: null });
  })
  .catch(err => {
    // Handle errors
    res.status(500).send('Database error: ' + err.message);
  });
});

module.exports = router;
