document.getElementById('signupForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const body = Object.fromEntries(formData.entries());

  const res = await fetch('/api/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  const data = await res.json();
  if (data.message === 'User registered') {
    document.getElementById('message').innerText = 'Registration successful! You can now log in.';
    // Optionally, redirect to login page
    // window.location.href = '/login.html';
  } else {
    document.getElementById('message').innerText = data.error || 'Registration failed';
  }
});

document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const body = Object.fromEntries(formData.entries());

  const res = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  const data = await res.json();
  if (data.accessToken) {
    localStorage.setItem('jwt', data.accessToken);
    window.location.href = '/dashboard.html';
  } else {
    document.getElementById('message').innerText = data.error || 'Login failed';
  }
});

function fetchWithAuth(url) {
  const token = localStorage.getItem('jwt');
  return fetch(url, {
    headers: { Authorization: 'Bearer ' + token }
  });
}

async function loadDashboard() {
  const tableBody = document.querySelector('#dashboardTable tbody');

  try {
    let res = await fetchWithAuth('/api/dashboard');
    if (res.status === 401 || res.status === 403) {
      const refreshRes = await fetch('/api/refresh', { method: 'POST', credentials: 'include' });
      const refreshData = await refreshRes.json();
      if (refreshData.accessToken) {
        localStorage.setItem('jwt', refreshData.accessToken);
        res = await fetchWithAuth('/api/dashboard');
      } else {
        return window.location.href = '/login.html';
      }
    }
    const users = await res.json();

    users.forEach(user => {
      const row = document.createElement('tr');

      row.innerHTML = `
        <td>${user.user_id}</td>
        <td>${user.username}</td>
        <td>${user.password}</td>
        <td>${user.refresh_token_id || 'N/A'}</td>
        <td>${user.issued_at || 'N/A'}</td>
        <td>${user.expires_at || 'N/A'}</td>
        <td>${user.user_agent || 'N/A'}</td>
        <td>${user.ip_address || 'N/A'}</td>
        <td>${user.token || 'N/A'}</td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    tableBody.innerHTML = '<tr><td colspan="9">Failed to load data. Please try again later.</td></tr>';
  }
}

function logout() {
  fetch('/api/logout', { method: 'POST', credentials: 'include' }).then(() => {
    localStorage.removeItem('jwt');
    window.location.href = '/login.html';
  });
}