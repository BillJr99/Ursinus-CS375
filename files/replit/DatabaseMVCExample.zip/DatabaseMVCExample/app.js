require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const setupSwagger = require('./swagger');
const app = express();
const PORT = process.env.PORT || 3000;

const db = require('./db'); // Initialize DB

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
setupSwagger(app);

app.set('view engine', 'ejs');

app.use('/api/students', require('./routes/studentRoutes'));
app.use('/api/courses', require('./routes/courseRoutes'));
app.use('/api/enrollments', require('./routes/enrollmentRoutes'));
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/', require('./routes/viewRoutes'));

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    console.log(`Swagger docs at http://localhost:${PORT}/api-docs`);
});