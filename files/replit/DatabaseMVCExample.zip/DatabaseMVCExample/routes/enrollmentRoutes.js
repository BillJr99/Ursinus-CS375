const express = require('express');
const router = express.Router();
const enrollmentController = require('../controllers/enrollmentController');
const courseController = require('../controllers/courseController');
const studentController = require('../controllers/studentController');
const { verifyAccessToken } = require('../auth/jwt');
const db = require('../db');

/**
 * @swagger
 * tags:
 *   name: Enrollments
 *   description: API endpoints for managing enrollments
 */

/**
 * @swagger
 * /api/enrollments:
 *   get:
 *     summary: Retrieve a list of enrollments
 *     tags: [Enrollments]
 *     responses:
 *       200:
 *         description: A list of enrollments.
 */
router.get('/', enrollmentController.list);

/**
 * @swagger
 * /api/enrollments:
 *   post:
 *     summary: Enroll a student in a course
 *     tags: [Enrollments]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               student_id:
 *                 type: integer
 *               course_id:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Enrollment created successfully.
 */
router.post('/', verifyAccessToken, enrollmentController.create);

/**
 * @swagger
 * /api/enrollments/{id}:
 *   delete:
 *     summary: Remove a student's enrollment
 *     tags: [Enrollments]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the enrollment to remove
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Enrollment removed successfully.
 */
router.delete('/:id', verifyAccessToken, enrollmentController.remove);

/**
 * @swagger
 * /api/enrollments/{id}:
 *   get:
 *     summary: Get an enrollment by ID
 *     tags: [Enrollments]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the enrollment to retrieve
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: An enrollment object
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: integer
 *                 student_id:
 *                   type: integer
 *                 course_id:
 *                   type: integer
 *                 enrollment_date:
 *                   type: string
 *                   format: date
 *       404:
 *         description: Enrollment not found
 */
router.get('/:id', enrollmentController.getById);

module.exports = router;
