const db = require('../db');

exports.createCourse = (name, code, callback) => {
    db.run(
        'INSERT INTO Course (name, code) VALUES (?, ?)',
        [name, code],
        function (err) {
            callback(err, this?.lastID);
        }
    );
};

exports.getAllCourses = (callback) => {
    db.all('SELECT * FROM Course', [], callback);
};

exports.updateCourse = (id, name, code, callback) => {
    db.run(
        'UPDATE Course SET name = ?, code = ? WHERE id = ?',
        [name, code, id],
        function (err) {
            callback(err, this?.changes);
        }
    );
};

exports.deleteCourse = (id, callback) => {
    db.run('DELETE FROM Course WHERE id = ?', [id], function (err) {
        callback(err, this?.changes);
    });
};
