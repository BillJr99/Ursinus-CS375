def get_grade(numgrade):
  """Returns the letter grade for a course given the numerical   
    grade average.

    Parameters
    ----------
    numgrade : float, required
        The number grade between 0-100

    Returns
    -------
    The letter grade associated with that numeric grade on a 
    90/80/70/60 scale
    """
  if numgrade >= 90:
    return "A"
  elif numgrade >= 80:
    return "B"
  elif numgrade >= 70:
    return "C"
  elif numgrade >= 60:
    return "D"
  else:
    return "F"
